//
//  NewTruckVC.swift
//  Truckers
//
//  Created by Ala'a Amerkani on 6/1/17.
//  Copyright © 2017 WARAQAT. All rights reserved.
//

import UIKit

class NewTruckVC: UIViewController, UIPickerViewDelegate , UIPickerViewDataSource , UINavigationControllerDelegate {

    @IBOutlet weak var truckName: UITextField!
    @IBOutlet weak var selectPic: UIButton!
    @IBOutlet weak var ShowPic: UIImageView!
    @IBOutlet weak var SelectService: UIPickerView!
    @IBOutlet weak var aboutTruck: UITextView!
    @IBOutlet weak var truckMobile: UITextField!
    @IBOutlet weak var truckEmail: UITextField!
    @IBOutlet weak var addTruckBtn: UIButton!
    
    
    var pickerData = [AnyObject]()
    var pickerData2 = [AnyObject]()
    
    var imageSelected = false
    var uuid = String()
    

    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.hideKeyboardWhenTappedAround()
        self.automaticallyAdjustsScrollViewInsets = false
        selectPic.backgroundColor = UIColor.clear
        selectPic.titleLabel?.textColor = appRedColor
        
        addTruckBtn.backgroundColor = appRedColor
        
        self.SelectService.dataSource = self
        self.SelectService.delegate = self
         loadCategories()
    }
    
    // pre load func
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        // call func of laoding posts
       
    }
    
    // select image
    @IBAction func select_click(_ sender: Any) {
        
        // calling picker for selecting iamge
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        picker.allowsEditing = true
        self.present(picker, animated: true, completion: nil)
        
    }
    
    
    // selected image in picker view
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        ShowPic.image = info[UIImagePickerControllerEditedImage] as? UIImage
        self.dismiss(animated: true, completion: nil)
        
        // cast as a true to save image file in server
        if ShowPic.image == info[UIImagePickerControllerEditedImage] as? UIImage {
            imageSelected = true
        }
    }
    
    // custom body of HTTP request to upload image file
    
    
    func createBodyWithParams(_ param: NSMutableDictionary?, filePathKey: String?, imageDataKey: Data, boundary: String) -> NSData {
        
        let body = NSMutableData();
        
        if param != nil {
            for (key, value) in param! {
                
                if(value is String || value is NSString){
                body.appendString("--\(boundary)\r\n")
                body.appendString("Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n")
                body.appendString("\(value)\r\n")
                }
            }
        }
        
        
        // if file is not selected, it will not upload a file to server, because we did not declare a name file
        var filename = ""
        
        if imageSelected == true {
            filename = "truck-\(uuid).jpg"
        }
        
        let mimetype = "image/jpg"
        
        body.appendString("--\(boundary)\r\n")
        body.appendString("Content-Disposition: form-data; name=\"\(filePathKey!)\"; filename=\"\(filename)\"\r\n")
        body.appendString("Content-Type: \(mimetype)\r\n\r\n")
        body.append(imageDataKey as Data)
        body.appendString("\r\n")
        
        body.appendString("--\(boundary)--\r\n")
        
        return body as NSMutableData
        
    }
    
   
    
// function sending requset to PHP to uplaod a file
func addTruck() {
    
    // shortcuts to data to be passed to php file
    let user_id         = user!["user_id"] as! String
    let uuid            = randomString(length: 8)
    let truck_name      = truckName.text!
    let truck_email     = truckEmail.text!
    let truck_mobile    = truckMobile.text!
    let about_truck     = aboutTruck.text!

    let selectedValue = String(self.SelectService.selectedRow(inComponent: 0))
    
    // url path to php file
    let url = URL(string: "http://www.wsi.sa/truckers/secure/new_truck.php")!
    var request = URLRequest(url: url)
    request.httpMethod = "POST"
    
    // param to be passed to php file
    let param : [String: Any] = [
        "user_id" : user_id as String,
        "uuid"      : uuid as String,
        "truck_name" : truck_name as String,
        "truck_email" : truck_email as String,
        "truck_mobile" : truck_mobile as String,
        "truck_category" : selectedValue as String,
        "about_truck" : about_truck as String
    ]  as Dictionary<String, String>
    
    
    //print(param)
    let boundary = "Boundary-\(uuid)"
    request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
    
    // if picture is selected, compress it by half
    var imageData = Data()
    
    if ShowPic.image != nil {
        imageData = UIImageJPEGRepresentation(ShowPic.image!, 0.5)!
    }
    
    // ... body
     request.httpBody = createBodyWithParams((param as! NSMutableDictionary), filePathKey: "file", imageDataKey: imageData, boundary: boundary) as Data
    
    
    // launch session
    URLSession.shared.dataTask(with: request  as URLRequest) { data, response, error in
        
        // get main queu to communicate back to user
        DispatchQueue.main.async(execute: {
            
            
            if error == nil {
                
                do {
                    
                    // json containes $returnArray from php
                    let json = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                    
                    
                    
                    // declare new var to store json inf
                    guard let parseJSON = json else {
                        print("Error while parsing")
                        return
                    }
                    
                    // get message from $returnArray["message"]
                    let message = parseJSON["message"]
                    
                    // if there is some message - post is made
                    if message != nil {
                        
                        let message = parseJSON["message"] as! String
                        
                        DispatchQueue.main.async(execute: {
                            appDelegate.infoView(message: message, color: appGreenColor)
                        })

                        
                        // switch to another scene
                       // self.tabBarController?.selectedIndex = 0
                        
                    }
                    
                } catch {
                    
                    // get main queue to communicate back to user
                    DispatchQueue.main.async(execute: {
                        let message = "\(error)"
                        appDelegate.infoView(message: message, color: appRedColor)
                    })
                    return
                    
                }
                
            } else {
                
                // get main queue to communicate back to user
                DispatchQueue.main.async(execute: {
                    let message = error!.localizedDescription
                    appDelegate.infoView(message: message, color: appRedColor)
                })
                return
                
            }
            
            
        })
        
        }
    .resume()
    
    }
    
    @IBAction func AddBtn_Click(_ sender: Any) {
        
        if truckName.text!.isEmpty || aboutTruck.text!.isEmpty || truckEmail.text!.isEmpty || truckMobile.text!.isEmpty {
            
            //red placeholder
            truckName.attributedPlaceholder = NSAttributedString(string: "الاسم بالكامل", attributes: [NSForegroundColorAttributeName : appRedColor])
            truckEmail.attributedPlaceholder = NSAttributedString(string: "ادخل البريد الإلكتروني للعربة", attributes: [NSForegroundColorAttributeName : appRedColor])
            truckMobile.attributedPlaceholder = NSAttributedString(string: "أدخل رقم جوال العربة", attributes: [NSForegroundColorAttributeName : appRedColor])
            
        }else{
            
            let providedEmailAddress = truckEmail.text
            let isEmailAddressValid = isValidEmailAddress(emailAddressString: providedEmailAddress!)
            
            if (!isEmailAddressValid && !truckEmail.text!.isEmpty){
                
                DispatchQueue.main.async(execute: {
                    appDelegate.infoView(message: "لقد آدخلت بريد خاطئ", color: appRedColor)
                })
            } else {
                
                addTruck()
            }
            
        }
    }
    
    // func of loading posts from server
    func loadCategories() {
        
        // accessing php file via url path
        let url2 = URL(string: "http://www.wsi.sa/truckers/secure/get_categories.php")!
        
        // declare request to proceed php file
        var request2 = URLRequest(url: url2)
        
        // declare method of passing information to php file
        request2.httpMethod = "GET"
        
        // pass information to php file
        let body2 = ""
        request2.httpBody = body2.data(using: String.Encoding.utf8)
        
        // launch session
        URLSession.shared.dataTask(with: request2) { data, response, error in
            
            // get main queue to operations inside of this block
            DispatchQueue.main.async(execute: {
                
                // no error of accessing php file
                if error == nil {
                    
                    do {
                        
                        // getting content of $returnArray variable of php file
                        let json2 = try JSONSerialization.jsonObject(with: data!, options: .mutableContainers) as? NSDictionary
                        
                        self.pickerData.removeAll(keepingCapacity: false)
                        
                        
                        // declare new parseJSON to store json
                        guard let parseJSON2 = json2 else {
                            print("Error while parsing")
                            return
                        }
                        
                        // declare new categories to store parseJSON
                        guard let categories = parseJSON2["categories"] as? [AnyObject] else {
                            print("Error while parseJSONing.")
                            return
                        }
                        
                        self.pickerData = categories

                        for i in 0 ..< self.pickerData.count {
                            
                            let cat_name = self.pickerData[i]["category_name_ar"] as? String
                            
                            self.pickerData2.append(cat_name as AnyObject)

                        }
                        
                        // append all posts var's inf to categories
                        
                        // print(self.pickerData2)
                        
                        // reload tableView to show back information
                        self.SelectService.reloadAllComponents()
                        
                        
                    } catch {
                    }
                    
                } else {
                }
                
            })
            
            }.resume()
        
    }
    

    // returns the number of 'columns' to display.
    func numberOfComponents( in pickerView: UIPickerView) -> Int
    {
        return 1
    }
    
    // returns the # of rows in each component..
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int
    {
        return pickerData2.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String?
    {
        return (pickerData2[row] as! String)
    }
    
    func pickerView(_ pickerView: UIPickerView, viewForRow row: Int, forComponent component: Int, reusing view: UIView?) -> UIView {
        
        
        let pickerLabel = UILabel()
        pickerLabel.textColor = UIColor.black
        pickerLabel.text = (pickerData2[row] as! String)
        pickerLabel.font = UIFont(name: "GE SS TWO", size: 14) // In this use your custom font
        pickerLabel.textAlignment = .center
        
        return pickerLabel
        
    }
    
    
    

}




// Creating protocol of appending string to var of type data
extension NSMutableData {
    
    func appendString(_ string : String) {
        
        let data = string.data(using: String.Encoding.utf8, allowLossyConversion: true)
        append(data!)
        
    }
    
}


